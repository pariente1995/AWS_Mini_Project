package com.sagaji.shoppingmall.service.order;

public interface OrderService {

}
