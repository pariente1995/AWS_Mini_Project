package com.sagaji.shoppingmall.vo;

public class OrderVO {

}
