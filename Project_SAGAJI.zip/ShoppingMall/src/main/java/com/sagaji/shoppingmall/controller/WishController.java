package com.sagaji.shoppingmall.controller;

import org.springframework.beans.factory.annotation.Autowired;

import com.sagaji.shoppingmall.service.wish.WishService;

public class WishController {
	@Autowired
	private WishService wishService;
}
