package com.sagaji.shoppingmall.service.admin.impl;

public class AdminServiceImpl {

}
