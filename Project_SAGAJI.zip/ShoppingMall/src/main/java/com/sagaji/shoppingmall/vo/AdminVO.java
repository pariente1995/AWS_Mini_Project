package com.sagaji.shoppingmall.vo;

public class AdminVO {

}
