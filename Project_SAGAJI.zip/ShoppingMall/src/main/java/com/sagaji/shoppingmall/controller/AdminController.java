package com.sagaji.shoppingmall.controller;

public class AdminController {

}
