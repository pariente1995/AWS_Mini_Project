package com.sagaji.shoppingmall.service.order.impl;

public class OrderDAO {

}
