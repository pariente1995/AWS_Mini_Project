package com.sagaji.shoppingmall.service.wish.impl;

public class WishServiceImpl {

}
