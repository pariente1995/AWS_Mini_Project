package com.sagaji.shoppingmall.service.wish;

public interface WishService {

}
