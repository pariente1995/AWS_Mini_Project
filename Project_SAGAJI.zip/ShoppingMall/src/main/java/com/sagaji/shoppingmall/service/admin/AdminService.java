package com.sagaji.shoppingmall.service.admin;

public interface AdminService {

}
